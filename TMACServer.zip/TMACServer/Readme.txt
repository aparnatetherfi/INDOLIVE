please add the below keys in Template.json file TMAC SERVER(primary).

<add key="Recovery_RecoverVoiceOnSoftLoginEnabled" value="1" />

<add key="AgentSession_NoLogoutOnStop" value="1" />
----------------------------------------------------------
------------------------------------------------------------

Please Update the below key in Template.json file of TMACSERVER HA

<add key="CustomServer_Params_1" value="extConnect1|extConnect2" />